"""
Subcontroller module for Alien Invaders

This module contains the subcontroller to manage a single level or wave in
the Alien Invaders game.  Instances of Wave represent a single wave. Whenever
you move to a new level, you are expected to make a new instance of the class.

The subcontroller Wave manages the ship, the aliens and any laser bolts on
screen. These are model objects.  Their classes are defined in models.py.

Most of your work on this assignment will be in either this module or
models.py. Whether a helper method belongs in this module or models.py is
often a complicated issue.  If you do not know, ask on Piazza and we will
answer.

Authors: Suhani Patel (sjp269), Vendela Perry (vap58)
Date: December 7, 2021
"""
from game2d import *
from consts import *
from models import *
import random

# PRIMARY RULE: Wave can only access attributes in models.py via getters/setters
# Wave is NOT allowed to access anything in app.py (Subcontrollers are not
# permitted to access anything in their parent. To see why, take CS 3152)


class Wave(object):
    """
    This class controls a single level or wave of Alien Invaders.

    This subcontroller has a reference to the ship, aliens, and any laser bolts
    on screen. It animates the laser bolts, removing any aliens as necessary.
    It also marches the aliens back and forth across the screen until they are
    all destroyed or they reach the defense line (at which point the player
    loses). When the wave is complete, you  should create a NEW instance of
    Wave (in Invaders) if you want to make a new wave of aliens.

    If you want to pause the game, tell this controller to draw, but do not
    update.  See subcontrollers.py from Lecture 24 for an example.  This
    class will be similar to than one in how it interacts with the main class
    Invaders.

    All of the attributes of this class ar to be hidden. You may find that
    you want to access an attribute in class Invaders. It is okay if you do,
    but you MAY NOT ACCESS THE ATTRIBUTES DIRECTLY. You must use a getter
    and/or setter for any attribute that you need to access in Invaders.
    Only add the getters and setters that you need for Invaders. You can keep
    everything else hidden.

    """
    # HIDDEN ATTRIBUTES:
    # Attribute _ship: the player ship to control
    # Invariant: _ship is a Ship object or None
    #
    # Attribute _aliens: the 2d list of aliens in the wave
    # Invariant: _aliens is a rectangular 2d list containing Alien objects or None
    #
    # Attribute _bolts: the laser bolts currently on screen
    # Invariant: _bolts is a list of Bolt objects, possibly empty
    #
    # Attribute _dline: the defensive line being protected
    # Invariant : _dline is a GPath object
    #
    # Attribute _lives: the number of lives left
    # Invariant: _lives is an int >= 0
    #
    # Attribute _time: the amount of time since the last Alien "step"
    # Invariant: _time is a float >= 0s
    #
    # You may change any attribute above, as long as you update the invariant
    # You may also add any new attributes as long as you document them.
    # LIST MORE ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    #
    # Attribute _steps: the number of alien steps that have occurred
    # Invariant: _steps is an int >=0
    #
    # Attribute _alien_fire: the number of alien steps between shots
    # Invariant: _alien_fire is a random int between 1 and BOLT_RATE
    #
    # Attribute _noship: the status of the ship (dead or alive)
    # Invariant: _noship is a boolean, True if the ship is None, False otherwise
    #
    # Attribute _animator: animation attribute to trigger ship animations
    # Invariant: _animator is a coroutine or None value
    #
    # Attribute _pewsound: sound for when ship fires a bolt
    # Invariant: _pewsound is a Sound() object
    #
    # Attribute _boomsound: sound for when ship explodes
    # Invariant: _boomsound is a Sound() object

    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    # Getter for list of aliens
    def get_Aliens(self):
        """
        Returns the list of aliens

        Invariant: the value is a non-empty list of aliens or None values.
        """
        return self._aliens

    # Getter for status of ship after animation
    def ship_dead(self):
        """
        Returns the status of the ship

        Invariant: the value is a boolean, True or False.
        """
        return self._noship2

    # Getter for if ship needs to be reset
    def _ship_continue(self, boole):
        """
        Sets the status of the ship if the state is STATE_CONTINUE

        Parameter boole: the status of the ship
        Invariant: boole is a boolean, True or False.
        """
        assert type(boole) == bool

        self._noship2 = boole
        self._noship = boole
        self._ship = Ship(0)

    # Getter for if aliens have passed the defense line
    def aliens_dline(self):
        """
        Checks if aliens have passed the defense line

        Invariant: the value is a boolean, True or False
        """
        empty = True
        for row in range(len(self._aliens)):
            for col in range(len(self._aliens[row])):
                if self._aliens[row][col] != None:
                    empty = False
        if empty == False:
            alien = self.bottomost_alien()
            if alien.y -ALIEN_HEIGHT/2 < DEFENSE_LINE:
                return True
            else:
                return False

    # Getter for if the aliens are all dead
    def aliens_death(self):
        """
        Checks if all aliens are killed

        Invariant: the value is a boolean, True or False
        """
        counter = 0
        total = ALIEN_ROWS * ALIENS_IN_ROW
        for row in range(len(self._aliens)):
            for col in range(len(self._aliens[row])):
                al = self._aliens[row][col]
                if al != None:
                    counter += 1
        if counter > 0:
            return False
        return True

    # Getter for points
    def points(self):
        """
        Checks how many aliens are dead and assigns them points based on what
        row they were in.

        Invariant: the value is an int >= 0
        """
        # score extra credit
        lst = []
        base_num = 1
        dict = {}
        total = 0
        for row in range(ALIEN_ROWS):
            lst.append(row)
        for i in range(len(lst)):
            dict[lst[i]] = base_num + base_num*i
        dict[lst[-1]+1] = 50
        lst2 = []
        for row in range(len(self._aliens)):
            for col in range(len(self._aliens[row])):
                if self._aliens[row][col] == None:
                    lst2.append(row)
        for i in range(len(lst2)):
            if lst2[i] in dict:
                total += dict[lst2[i]]
            else:
                total += 10
        return total

    # INITIALIZER (standard form) TO CREATE SHIP, BOLTS, DLINE, AND ALIENS
    def __init__(self):
        """
        Initializes a new wave of aliens, bolts, a defense line, and a ship
        """
        self._aliens = []
        self.alien_wave()
        self._ship = Ship(0)
        self._dline = (GPath(points = [0,DEFENSE_LINE,GAME_WIDTH,DEFENSE_LINE],
        linewidth = 2, linecolor = 'purple'))
        self._time = 0
        self._moving_right = True
        self._bolts = []
        self._steps = 0
        self._alien_fire = None
        self._animator = None
        self._noship = None
        self._noship2 = None
        self._pewsound = Sound('pew1.wav')
        self._boomsound = Sound('blast2.wav')
        self._speed = ALIEN_SPEED

    # UPDATE METHOD TO MOVE THE SHIP, ALIENS, AND LASER BOLTS
    def _update(self,input,dt):
        """
        Animates a single wave of aliens, bolts, and the ship

        Parameter input: the user input
        Invariant: input is a valid input and GInput object

        Parameter dt: time in seconds since the last call to update
        Invariant: dt is a number (float or int)
        """
        assert isinstance(input,GInput)
        assert type(dt) == int or type(dt) == float

        self._move_ship(input)
        self._move_aliens(dt)
        if self._animator == None:
            if input.is_key_down('up') and self.no_player_bolt() and self._ship != None:
                self._pewsound.play()
                self._bolts.append(Bolt(self._ship.x, self._ship.y, True))
        self._move_bolts()
        self._check_colliding_aliens()
        self._check_colliding_ship()
        if not self._animator is None:          # We have something to animate
            try:
                self._animator.send(dt)         # Tell it how far to animate
            except:
                self._boomsound.play()
                self._animator = None
                self._noship2 = True
                self._ship = None
        elif self._noship == True:
            self._animator = self._ship._animate()
            next(self._animator)

    # DRAW METHOD TO DRAW THE SHIP, ALIENS, DEFENSIVE LINE AND BOLTS
    def draw(self, view):
        """
        Calls the draw functions for Ship, Aliens, Defensive Line, and Bolts

        Parameter view: the game view, used in drawing
        Invariant: view is an instance of GView (inherited from GameApp)
        """
        assert isinstance(view,GView)

        self._draw_aliens(view)
        self._draw_ship(view)
        self._draw_dline(view)
        self._draw_bolts(view)

    def _draw_aliens(self,view):
        """
        Helper function to draw aliens in self._aliens

        Parameter view: the game view, used in drawing
        Invariant: view is an instance of GView (inherited from GameApp)
        """
        assert isinstance(view, GView)

        for row in range(len(self._aliens)):
            for col in range(len(self._aliens[row])):
                al = self._aliens[row][col]
                if al:
                    al.draw(view)

    def _draw_ship(self,view):
        """
        Helper function to draw self._ship

        Parameter view: the game view, used in drawing
        Invariant: view is an instance of GView (inherited from GameApp)
        """
        assert isinstance(view,GView)

        if self._ship != None:
            ship = self._ship
            ship.draw(view)

    def _draw_dline(self,view):
        """
        Helper function to draw the defense line

        Parameter view: the game view, used in drawing
        Invariant: view is an instance of GView (inherited from GameApp)
        """
        assert isinstance(view, GView)

        dline = self._dline
        dline.draw(view)

    def _draw_bolts(self, view):
        """
        Helper function to draw the bolts in self._bolts

        Parameter view: the game view, used in drawing
        Invariant: view is an instance of GView (inherited from GameApp)

        """
        assert isinstance(view,GView)

        for bolt in self._bolts:
            bolt.draw(view)

    # HELPER METHODS FOR COLLISION DETECTION
    def _check_colliding_aliens(self):
        """
        Function to check if player bolt collides with aliens and delete aliens
        and bolt if collision is detected.

        """
        active_bolt = None
        for x in range(len(self._bolts)):
            if self._bolts[x].isPlayerBolt():
                active_bolt = self._bolts[x]
                bolt_index = x
        if active_bolt:
            for i in range(len(self._aliens)):
                for j in range(len(self._aliens[i])):
                    if self._aliens[i][j]:
                        if self._aliens[i][j].collides(active_bolt):
                            self._aliens[i][j] = None
                            del self._bolts[bolt_index]

    def _check_colliding_ship(self):
        """
        Function to check if alien bolt collides with the ship, deletes bolt if
        collision is detected, and sets ship status attribute.

        """
        active_bolt = None
        for x in range(len(self._bolts)):
            if not self._bolts[x].isPlayerBolt():
                active_bolt = self._bolts[x]
                bolt_index = x
        if active_bolt and self._ship != None:
            if self._ship.collides(active_bolt):
                self._noship = True
                del self._bolts[bolt_index]

    # HELPER METHOD TO CREATE ALIEN WAVE
    def alien_wave(self):
        """
        Function to add ALIEN_ROWS of ALIENS_IN_ROW aliens to the self._aliens
        2D list.

        """
        lst = []
        n = 0
        # figure out how to center
        for row in range(ALIEN_ROWS):
            lst.append([])
            for col in range(ALIENS_IN_ROW):
                xcoord = (ALIEN_H_SEP*(col+1)) + (ALIEN_WIDTH/2) + \
                (((ALIEN_WIDTH/2)*(col*2)))
                ycoord = (GAME_HEIGHT-ALIEN_CEILING)-(ALIEN_HEIGHT/2)-\
                (ALIEN_V_SEP*(row))-((ALIEN_HEIGHT/2)*(row*2))
                alien_obj = Alien(xcoord, ycoord, ALIEN_IMAGES[n%3])
                lst[row].append(alien_obj)
            n += 1
        self._aliens = lst
        return self._aliens

    # HELPER METHODS FOR MOVEMENT
    def _move_ship(self, input):
        """
        Moves ship left and right based on user input.

        Parameter input: the user input
        Invariant: input is a valid input and GInput object
        """
        assert isinstance(input,GInput)
        if self._animator == None:
            if self._ship!= None:
                if input.is_key_down('left'):
                    self._ship.move_ship_left()
                elif input.is_key_down('right'):
                    self._ship.move_ship_right()

    def _move_aliens(self,dt):
        """
        Moves aliens right and left every update every dt seconds. Moves aliens
        down if hits left or right boundary and switches direction.

        Parameter dt: time in seconds since the last call to update
        Invariant: dt is a number, float or int
        """
        assert type(dt) == int or type(dt) == float

        if self._time < self._speed:
            self._time = self._time + dt
        else:
            self._time = 0
            if self._moving_right:
                self.movement_handler_right()
                self.alien_bolt()
            else:
                self.movement_handler_left()
                self.alien_bolt()

    def movement_handler_right(self):
        """
        Helper function to move alien wave right and down.
        """
        lst = []
        for row in range(len(self._aliens)):
            for col in range(len(self._aliens[row])):
                if self._aliens[row][col]!=None:
                    lst.append([row, col])
        lst.sort()
        index = max(lst)
        right_alien = self._aliens[index[0]][index[1]]
        if right_alien.x + ALIEN_H_WALK + ALIEN_WIDTH/2 < GAME_WIDTH:
            for row in range(len(self._aliens)):
                for col in range(len(self._aliens[row])):
                    a1 = self._aliens[row][col]
                    if a1 != None:
                        a1.x += ALIEN_H_WALK
        else:
            for row in range(len(self._aliens)):
                for col in range(len(self._aliens[row])):
                    a1 = self._aliens[row][col]
                    if a1 != None:
                        a1.y -= ALIEN_V_WALK
                        self._moving_right = False

    def movement_handler_left(self):
        """
        Helper function to move alien wave left and down.
        """
        lst = []
        for row in range(len(self._aliens)):
            for col in range(len(self._aliens[row])):
                if self._aliens[row][col]!=None:
                    lst.append([row, col])
        lst.sort()
        index = min(lst)
        left_alien = self._aliens[index[0]][index[1]]
        if left_alien.x - ALIEN_H_WALK - ALIEN_WIDTH/2 > 0:
            for row in range(len(self._aliens)):
                for col in range(len(self._aliens[row])):
                    a1 = self._aliens[row][col]
                    if a1 != None:
                        a1.x -= ALIEN_H_WALK
        else:
            for row in range(len(self._aliens)):
                for col in range(len(self._aliens[row])):
                    a1 = self._aliens[row][col]
                    if a1 != None:
                        a1.y -= ALIEN_V_WALK
                self._moving_right = True

    def _move_bolts(self):
        """
        Moves bolts depending on their type- if bolt is a player bolt, it moves
        it upward and deletes it if it passes upper game boundary; if it isn't,
        it moves it downwards and deletes it if it passed lower game boundary.
        """
        i = 0
        while i < (len(self._bolts)):
            if self._bolts[i].isPlayerBolt():
                self._bolts[i].y += BOLT_SPEED
                if self._bolts[i].y -BOLT_HEIGHT/2>GAME_HEIGHT:
                    del self._bolts[i]
            else:
                self._bolts[i].y -= BOLT_SPEED
                if self._bolts[i].y - BOLT_HEIGHT/2<0:
                    del self._bolts[i]
            i +=1

    # HELPER METHODS FOR FIRING BOLTS FROM ALIENS
    # Helper for restricting rate of fire
    def no_player_bolt(self):
        """
        Restricts rate of fire by not allowing user to shoot a bolt if a player
        bolt is already on the screen.
        """
        for bolt in self._bolts:
            if bolt.isPlayerBolt():
                return False
        return True

    def alien_bolt(self):
        """
        Randomly fires alien bolts by first choosing a random int between 1 and
        BOLT_RATE and seeing if that random number equals the number of steps taken.
        If it does, then the alien fires. If not, the method increments the number
        of steps by 1, and checks if that number equals BOLT_RATE or the random
        number previously chosen. If so, it shoots.
        """
        self._alien_fire = random.randint(1, BOLT_RATE)
        if self._alien_fire == BOLT_RATE:
            self.find_alien()
        else:
            if self._steps == BOLT_RATE:
                self.find_alien()
            else:
                self._steps += 1
        self._steps = 0

    def find_alien(self):
        """
        Helper to find the set the x and y of the bottommost alien and create a
        bolt at that location.
        """
        alien = self.bottomost_alien()
        x = alien.x
        y = alien.y
        self._bolts.append(Bolt(x, y, False))
        self._steps = 0

    def bottomost_alien(self):
        """
        Helper to find the bottommost non-empty alien of a random column of non-empty
        aliens.
        """
        empty = True
        for row in range(len(self._aliens)):
            for col in range(len(self._aliens[row])):
                if self._aliens[row][col] != None:
                    empty = False
        if empty == False:
            lst = []
            for col in range(len(self._aliens[0])):
                if self._aliens[0][col] != None:
                    lst.append(col)
            randcolindex = random.choice(lst)
            lst2 = []
            for row in range(len(self._aliens)):
                if self._aliens[row][randcolindex] == None:
                    lst2.append(False)
                else:
                    lst2.append(True)
            lst2.reverse()
            bottommost_alien = lst2.index(True)
            index = len(lst2)-bottommost_alien-1
            return self._aliens[index][randcolindex]
